package myJavaClasses;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author osman
 */
public class User {
    public String name ; 
    public String email ;
    public String mobile ;
    
    public User(String n , String e , String m){
        this.name = n;
        this.email = e;
        this.mobile = m;
    }
    
    public User(){};
}



